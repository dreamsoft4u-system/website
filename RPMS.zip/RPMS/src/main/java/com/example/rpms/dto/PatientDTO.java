package com.example.rpms.dto;

public class PatientDTO {
   public String patientMr;
   public String sugarUnit;
   public String pressureUnit;
   public String sugarMin;
   public String sugarMax;
   public String pressureMin;
   public String pressureMax;
   
}
